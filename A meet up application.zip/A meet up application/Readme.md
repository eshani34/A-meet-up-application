# NBAD Project

* All .html files are placed in the root folder.
* css files are placed in the respective folders.
* js files are placed under the scripts folder.
* use bootstrap cdn v5.
* when adding new page create respective folder and it should have two stylesheets one contains styles of header and footer other is specific styles sheet of that page keep both styles separated.

## For HTML File

* use the following boiler plate code to include bootstrap styles.

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Lab1</title>
    <!-- Bootstrap cdn links -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
      crossorigin="anonymous"
    ></script>
    <!-- css files -->
    <!-- js files -->
  </head>
  <body>
    <!-- header section -->
    <!-- main section -->
    <!-- footer section -->
  </body>
</html>
```

* import neccessary styles and scripts.
* use defer attribute for scripts.
* include comments for better understanding.
* dont use inline or internal stylings always use external stylesheets.

## want to add new Event?
* add it to events.json file everything will be handled.
* Make sure all props id,title,category,host,location,time,descTitle,description are provided.
* incase description contains html use validator so it doesnt break

## Checks
* use validator for .html in https://validator.w3.org/nu/#textarea before pushing.
* Check all links are working.

## Repository
* https://github.com/Kalyan-1707/NBAD-Project

## Copyrights
* All categories are from - https://www.meetup.com/
* https://picsum.photos/200/300