const express = require('express');
const controller = require('../controllers/user');
const {isGuest, isLoggedIn} = require('../middlewares/auth');
const { loginLimiter } = require('../middlewares/rateLimiter');
const { validateSignup, validateResult, validateLogin } = require('../middlewares/validators');

const router = express.Router();


router.get('/', controller.index);

// signup route
router.get('/new',isGuest, controller.new);

//create user
router.post('/',isGuest, loginLimiter,validateSignup, validateResult, controller.create);

// login
router.get('/login', isGuest,controller.login);

// authenticate login
router.post('/login',loginLimiter, isGuest, validateLogin, validateResult, controller.authenticate);

//profile
router.get('/profile', isLoggedIn,controller.profile);

//logout
router.get('/logout', isLoggedIn ,controller.logout);


module.exports = router;