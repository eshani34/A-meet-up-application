exports.index  =(req,res)=>{
    res.render('index');
};
exports.about=(req,res)=>{
    res.render('./show/about');
};
exports.contact=(req,res)=>{
    res.render('./show/contact');
};





